package com.getredeemcode.app.ui.screens

import android.content.Intent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel
import kotlinx.coroutines.delay

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    vm: AppViewModel,
    onScratch: () -> Unit,
    onQuiz: () -> Unit,
    onCaptcha: () -> Unit,
    onRedeem: () -> Unit,
    onRefer: () -> Unit,
    onPrivacy: () -> Unit,
    onTerms: () -> Unit
) {
    val context = LocalContext.current
    var showTopUp by remember { mutableStateOf(false) }
    var showDropdown by remember { mutableStateOf(false) }
    var showBonusModal by remember { mutableStateOf(false) }
    var showVideoNotLoading by remember { mutableStateOf(false) }
    var showVideoModal by remember { mutableStateOf(false) }

    val adBanners = listOf(
        AdBannerData("Watch Ads & Earn", "FREE POINTS", "📺", listOf(Color(0xFF4a1fa8), Color(0xFF7c3aad), Color(0xFFa855f7))),
        AdBannerData("Complete Tasks Now", "BONUS STARS", "⭐", listOf(Color(0xFF1565c0), Color(0xFF1976d2), Color(0xFF42a5f5))),
        AdBannerData("Get Gift Cards", "REDEEM NOW", "🎁", listOf(Color(0xFFc62828), Color(0xFFe53935), Color(0xFFef9a9a)))
    )
    val pagerState = rememberPagerState(pageCount = { adBanners.size })
    LaunchedEffect(Unit) {
        while (true) {
            delay(3500)
            val next = (pagerState.currentPage + 1) % adBanners.size
            pagerState.animateScrollToPage(next)
        }
    }

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {

            // ── TOP BAR ──────────────────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth()
                    .background(Brush.linearGradient(listOf(Purple, PurpleDark)))
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Logo / TopUp button
                Box(
                    modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(PinkLight)
                        .clickable { vm.openTopUp(); showTopUp = true },
                    contentAlignment = Alignment.Center
                ) { Text("💰", fontSize = 24.sp) }
                Spacer(Modifier.width(12.dp))
                Text("Get Redeem Code", color = White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                // Gift icon (bonus)
                Text("🎁", fontSize = 26.sp, modifier = Modifier.clickable { showBonusModal = true }.padding(4.dp))
                Spacer(Modifier.width(16.dp))
                // Hamburger menu
                Box(modifier = Modifier.size(36.dp).clickable { showDropdown = !showDropdown }, contentAlignment = Alignment.Center) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        repeat(3) { Box(modifier = Modifier.size(22.dp, 2.5.dp).background(White, RoundedCornerShape(2.dp))) }
                    }
                }
            }

            // ── SCROLLABLE CONTENT ────────────────────────────────────────
            Column(
                modifier = Modifier.fillMaxSize().background(Color(0xFFf3f0ff))
                    .verticalScroll(rememberScrollState()).padding(bottom = 28.dp)
            ) {

                // BALANCE CARD
                Box(
                    modifier = Modifier.fillMaxWidth().padding(14.dp, 16.dp, 14.dp, 0.dp)
                        .clip(RoundedCornerShape(18.dp)).border(1.5.dp, Border, RoundedCornerShape(18.dp))
                        .background(White).padding(20.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("Your Balance", color = TextDark, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("⭐", fontSize = 28.sp); Spacer(Modifier.width(8.dp))
                                Text(vm.formatCoinShort(vm.coins), color = Purple, fontWeight = FontWeight.Black, fontSize = 26.sp)
                            }
                        }
                        GradientButton("Redeem", emoji = "🎁", onClick = onRedeem, fontSize = 17)
                    }
                }

                // BONUS CARD
                if (!vm.bonusClaimed) {
                    Spacer(Modifier.height(12.dp))
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp)
                            .clip(RoundedCornerShape(18.dp)).border(1.5.dp, Border, RoundedCornerShape(18.dp))
                            .background(White).clickable { showBonusModal = true }.padding(18.dp)
                    ) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFf3e8ff)), contentAlignment = Alignment.Center) { Text("🎁", fontSize = 30.sp) }
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text("New User Bonus!", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                                Text("Claim FREE 50 ⭐ Stars now →", color = Purple, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }
                }

                // AD BANNER CAROUSEL
                Spacer(Modifier.height(16.dp))
                HorizontalPager(
                    state = pagerState, modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 14.dp), pageSpacing = 12.dp
                ) { page ->
                    val banner = adBanners[page]
                    Box(
                        modifier = Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(16.dp))
                            .background(Brush.linearGradient(banner.colors))
                            .clickable { vm.openFullscreenAd() }.padding(14.dp)
                    ) {
                        Box(modifier = Modifier.align(Alignment.TopStart).clip(RoundedCornerShape(20.dp)).background(White.copy(alpha = 0.2f)).padding(horizontal = 8.dp, vertical = 3.dp)) {
                            Text("AD", color = White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Text("GetRedeemCode", color = White.copy(alpha = 0.9f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.TopEnd))
                        Text(banner.emoji, fontSize = 50.sp, modifier = Modifier.align(Alignment.CenterEnd))
                        Column(modifier = Modifier.align(Alignment.BottomStart)) {
                            Text("FREE", color = White.copy(alpha = 0.85f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(banner.sub, color = White, fontWeight = FontWeight.Black, fontSize = 22.sp)
                            Text(banner.title, color = White.copy(alpha = 0.8f), fontSize = 12.sp)
                        }
                        Box(modifier = Modifier.align(Alignment.BottomEnd).clip(RoundedCornerShape(6.dp)).background(Color.Black).clickable { vm.openFullscreenAd() }.padding(horizontal = 16.dp, vertical = 7.dp)) {
                            Text("▶ Play", color = White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }

                // PAGER DOTS
                Spacer(Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    repeat(adBanners.size) { idx ->
                        val isActive = pagerState.currentPage == idx
                        Box(modifier = Modifier.padding(horizontal = 3.dp)
                            .clip(if (isActive) RoundedCornerShape(4.dp) else CircleShape)
                            .then(if (isActive) Modifier.width(20.dp).height(8.dp) else Modifier.size(8.dp))
                            .background(if (isActive) Purple else Border))
                    }
                }

                // EARN STARS SECTION HEADER
                Spacer(Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("⚡", fontSize = 18.sp); Spacer(Modifier.width(6.dp))
                    Text("Earn Stars", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    Box(modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFFf3e8ff)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                        Text("⭐ ${vm.formatCoinShort(vm.coins)}", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))

                // TASK GRID
                val tasks = listOf(
                    TaskItem("📺", "Watch Video", "Earn per video") { showVideoModal = true },
                    TaskItem("🎰", "Scratch & Win", "Up to 100 ⭐") { vm.prepareScratch(); onScratch() },
                    TaskItem("🤖", "Recaptcha", "Earn per captcha") { vm.generateCaptchaText(); onCaptcha() },
                    TaskItem("🧠", "Play Quiz", "Answer & earn") { vm.prepareQuiz(); onQuiz() }
                )
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    tasks.chunked(2).forEach { rowTasks ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            rowTasks.forEach { task -> TaskCard(task = task, modifier = Modifier.weight(1f)) }
                            if (rowTasks.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // REFER & EARN CARD
                Box(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp)
                        .clip(RoundedCornerShape(18.dp)).border(1.5.dp, Border, RoundedCornerShape(18.dp))
                        .background(White).clickable { onRefer() }.padding(18.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFf3e8ff)), contentAlignment = Alignment.Center) { Text("🤝", fontSize = 30.sp) }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Refer & Earn", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                            Text("Invite friends & earn ⭐ together!", color = Purple, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Text("→", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    }
                }

                Spacer(Modifier.height(12.dp))

                // BUY STARS / TOP-UP CARD
                Box(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF6d28d9), Color(0xFF9b59d0), Color(0xFFf472b6))))
                        .clickable { vm.openTopUp(); showTopUp = true }.padding(18.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("⭐ Buy Stars", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                            Text("Top up & unlock redeem codes instantly!", color = White.copy(alpha = 0.85f), fontSize = 13.sp)
                        }
                        Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(White.copy(alpha = 0.2f)).padding(horizontal = 16.dp, vertical = 8.dp)) {
                            Text("Buy Now", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        // ── DROPDOWN MENU ───────────────────────────────────────────────────
        if (showDropdown) {
            Box(modifier = Modifier.fillMaxSize().clickable { showDropdown = false }.background(Color.Black.copy(alpha = 0.25f)))
            Box(
                modifier = Modifier.padding(top = 70.dp, end = 12.dp).align(Alignment.TopEnd)
                    .width(230.dp).clip(RoundedCornerShape(14.dp)).background(White).border(1.dp, Border, RoundedCornerShape(14.dp))
            ) {
                Column {
                    listOf(
                        Triple("🤝", "Refer & Earn") { showDropdown = false; onRefer() },
                        Triple("⭐", "Buy Stars") { showDropdown = false; vm.openTopUp(); showTopUp = true },
                        Triple("📺", "Why video not loading?") { showDropdown = false; showVideoNotLoading = true },
                        Triple("📋", "Privacy Policy") { showDropdown = false; onPrivacy() },
                        Triple("📄", "Terms of Service") { showDropdown = false; onTerms() }
                    ).forEachIndexed { idx, (emoji, label, action) ->
                        Row(modifier = Modifier.fillMaxWidth().clickable { action() }.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(emoji, fontSize = 18.sp); Spacer(Modifier.width(12.dp))
                            Text(label, color = TextDark, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        if (idx < 4) HorizontalDivider(color = Border.copy(alpha = 0.4f), thickness = 0.7.dp)
                    }
                }
            }
        }

        // ── BONUS MODAL ─────────────────────────────────────────────────────
        if (showBonusModal) {
            ModalOverlay(onDismiss = { showBonusModal = false }) {
                Text("🎁", fontSize = 52.sp)
                Spacer(Modifier.height(8.dp))
                Text("New User Bonus!", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Complete any task and earn stars!\nCollect 1000 stars to get ₹700 Google Play Code.",
                    color = TextGray, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 22.sp
                )
                Spacer(Modifier.height(20.dp))
                if (!vm.bonusClaimed) {
                    Box(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50.dp))
                            .background(Brush.linearGradient(listOf(Purple, Pink)))
                            .clickable { vm.claimBonus(context); showBonusModal = false }.padding(vertical = 18.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("🎉 Claim FREE 50 Stars!", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
                } else {
                    Text("✅ Bonus already claimed!", color = Purple, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(10.dp))
                    Box(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50.dp))
                            .border(1.5.dp, Border, RoundedCornerShape(50.dp)).clickable { showBonusModal = false }.padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("Close", color = TextGray, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
                }
            }
        }

        // ── VIDEO MODAL ─────────────────────────────────────────────────────
        if (showVideoModal) {
            LaunchedEffect(showVideoModal) { vm.resetVideo() }
            ModalOverlay(onDismiss = { vm.resetVideo(); showVideoModal = false }) {
                Text("📺 Watch Video", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Spacer(Modifier.height(16.dp))
                // Video player mock
                Box(modifier = Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val icon = if (vm.videoRunning) "⏸" else if (vm.videoCompleted) "✅" else "▶"
                        Text(icon, fontSize = 56.sp, color = White, modifier = Modifier.clickable { if (!vm.videoCompleted) vm.startVideo() })
                        Spacer(Modifier.height(8.dp))
                        Text(String.format("0:%02d", vm.videoTime), color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    val elapsed = 30 - vm.videoTime
                    Box(modifier = Modifier.fillMaxWidth().height(4.dp).align(Alignment.BottomStart).background(Color.Gray.copy(alpha = 0.4f))) {
                        Box(modifier = Modifier.fillMaxWidth(elapsed / 30f).fillMaxHeight().background(Purple))
                    }
                }
                Spacer(Modifier.height(10.dp))
                when {
                    !vm.videoRunning && !vm.videoCompleted -> Text("▶ Tap play to start watching", color = TextGray, fontSize = 13.sp)
                    vm.videoRunning -> Text("⏳ Watch full video to earn stars...", color = Purple, fontSize = 13.sp)
                    vm.videoCompleted -> Text("✅ Video complete! Claim your reward.", color = Color(0xFF22c55e), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(50.dp)).background(Border)
                            .clickable { vm.resetVideo(); showVideoModal = false }.padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("Cancel", color = TextGray, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
                    Box(
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(50.dp))
                            .background(if (vm.videoCompleted) Brush.linearGradient(listOf(Purple, Pink)) else Brush.linearGradient(listOf(Color.Gray, Color.LightGray)))
                            .clickable(enabled = vm.videoCompleted) {
                                vm.claimVideo(context); showVideoModal = false; vm.openFullscreenAd()
                            }.padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("🎬 Claim Reward", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
                }
            }
        }

        // ── FULLSCREEN AD ───────────────────────────────────────────────────
        if (vm.showFullscreenAd) {
            FullscreenAdOverlay(seconds = vm.adSeconds, phase = vm.adPhase, canClose = vm.adCanClose, onClose = { vm.closeFullscreenAd(context) })
        }

        // ── VIDEO NOT LOADING SHEET ─────────────────────────────────────────
        if (showVideoNotLoading) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)).clickable { }, contentAlignment = Alignment.BottomCenter) {
                Column(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                        .background(White).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(modifier = Modifier.width(40.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Border))
                    Spacer(Modifier.height(16.dp))
                    Text("📺 Video Not Loading?", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Spacer(Modifier.height(16.dp))
                    listOf(
                        "1. Slow internet / airplane mode ON — check your connection.",
                        "2. In your country maximum number of videos reached.",
                        "3. In your country video service is not available.",
                        "4. Wait for a minute, video will load successfully.",
                        "If video loads without VPN, use app without VPN. If not loading, try a VPN app."
                    ).forEach { tip ->
                        Text(tip, color = Purple, fontSize = 15.sp, lineHeight = 24.sp, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    Box(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50.dp))
                            .background(Brush.linearGradient(listOf(Purple, Pink))).clickable { showVideoNotLoading = false }.padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("Got it! Close", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
                }
            }
        }

        // ── TOP-UP OVERLAY ──────────────────────────────────────────────────
        if (showTopUp) {
            TopUpOverlay(vm = vm, onDismiss = { showTopUp = false })
        }

        // ── PAYMENT CONFIRM OVERLAY ─────────────────────────────────────────
        if (vm.showPaymentConfirm) {
            PaymentConfirmOverlay(vm = vm)
        }

        // ── TOAST ────────────────────────────────────────────────────────────
        if (vm.showToast) {
            LaunchedEffect(vm.showToast, vm.toastMsg) { delay(2500); vm.showToast = false }
            Box(modifier = Modifier.fillMaxSize().padding(bottom = 64.dp), contentAlignment = Alignment.BottomCenter) {
                Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(Color(0xFF1a1a2e)).padding(horizontal = 24.dp, vertical = 14.dp)) {
                    Text(vm.toastMsg, color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

// ─── Data classes ─────────────────────────────────────────────────────────────
data class AdBannerData(val title: String, val sub: String, val emoji: String, val colors: List<Color>)
data class TaskItem(val emoji: String, val title: String, val sub: String, val onClick: () -> Unit)

// ─── Task Card ─────────────────────────────────────────────────────────────────
@Composable
fun TaskCard(task: TaskItem, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.clip(RoundedCornerShape(18.dp))
            .border(1.5.dp, Border, RoundedCornerShape(18.dp)).background(White)
            .clickable { task.onClick() }.padding(16.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFf3e8ff)), contentAlignment = Alignment.Center) {
                Text(task.emoji, fontSize = 32.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text(task.title, color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(task.sub, color = TextGray, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}

// ─── Fullscreen Ad Overlay ────────────────────────────────────────────────────
@Composable
fun BoxScope.FullscreenAdOverlay(seconds: Int, phase: String, canClose: Boolean, onClose: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (phase == "video") {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📺", fontSize = 72.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Ad Playing...", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Text("${(20 - seconds).coerceAtLeast(0)}s remaining", color = Color.LightGray, fontSize = 16.sp)
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize().background(Color(0xFF1a1a2e)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Text("🎁", fontSize = 64.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Get Redeem Code App", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Earn free stars & redeem codes!", color = Color.LightGray, fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(20.dp))
                    Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(Purple).padding(horizontal = 32.dp, vertical = 14.dp)) {
                        Text("⬇ Install Now", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    }
                }
            }
        }
        // Progress bar
        val progress = (seconds / 25f).coerceIn(0f, 1f)
        Box(modifier = Modifier.fillMaxWidth().height(4.dp).align(Alignment.TopStart).background(Color.DarkGray)) {
            Box(modifier = Modifier.fillMaxWidth(progress).fillMaxHeight().background(Purple))
        }
        // AD badge
        Box(modifier = Modifier.padding(12.dp).align(Alignment.TopStart).clip(RoundedCornerShape(20.dp)).background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
            Text("AD", color = White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
        // Close button
        if (canClose) {
            Box(
                modifier = Modifier.padding(12.dp).align(Alignment.TopEnd).size(36.dp)
                    .clip(CircleShape).background(Color.Black.copy(alpha = 0.6f)).clickable { onClose() },
                contentAlignment = Alignment.Center
            ) { Text("✕", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        }
    }
}

// ─── Modal Overlay ─────────────────────────────────────────────────────────────
@Composable
fun ModalOverlay(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable { onDismiss() }, contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
                .clip(RoundedCornerShape(24.dp)).background(White).clickable { }.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) { content() }
    }
}
