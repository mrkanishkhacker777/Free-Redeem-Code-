package com.getredeemcode.app.ui.screens

import android.graphics.*
import android.view.MotionEvent
import android.view.View
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel

@Composable
fun ScratchScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    var scratchKey by remember { mutableStateOf(0) }

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            ScreenTopBar("🎰 Scratch & Win", vm.formatCoinShort(vm.coins), onBack)

            Column(
                modifier = Modifier.fillMaxSize().background(Color(0xFFf3f0ff))
                    .verticalScroll(rememberScrollState()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                // How it works
                Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFFf3e8ff)).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ℹ️", fontSize = 18.sp); Spacer(Modifier.width(10.dp))
                        Text("Scratch 40%+ to reveal your prize, then watch a quick ad to claim!", color = Purple, fontWeight = FontWeight.Bold, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }

                // Prize reveal banner
                Box(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF6d28d9), Color(0xFF9b59d0), Color(0xFFf472b6))))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎁 Your Prize", color = White.copy(alpha = 0.85f), fontSize = 14.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("⭐ ${vm.formatCoin(vm.pendingScratchCoins)}", color = White, fontWeight = FontWeight.Black, fontSize = 30.sp)
                        Text("stars", color = White.copy(alpha = 0.75f), fontSize = 13.sp)
                    }
                }

                if (!vm.scratchDone) {
                    Text("✋ Scratch 40%+ of the card to reveal!", color = Purple, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }

                // Progress bar
                if (vm.scratchProgress > 0f) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Scratch Progress", color = TextGray, fontSize = 12.sp)
                            Text("${(vm.scratchProgress * 100).toInt()}%", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Box(modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Border)) {
                            Box(modifier = Modifier.fillMaxWidth(vm.scratchProgress.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(Brush.linearGradient(listOf(Purple, Pink))))
                        }
                    }
                }

                // Scratch canvas
                Box(
                    modifier = Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(18.dp)).border(2.dp, Border, RoundedCornerShape(18.dp))
                ) {
                    // Prize underneath
                    Box(modifier = Modifier.fillMaxSize().background(White), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("⭐", fontSize = 64.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("You Won!", color = Purple, fontWeight = FontWeight.Black, fontSize = 22.sp)
                            Spacer(Modifier.height(6.dp))
                            Text("+${vm.formatCoin(vm.pendingScratchCoins)} Stars", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        }
                    }
                    // Scratch overlay
                    if (!vm.scratchDone) {
                        key(scratchKey) {
                            ScratchCanvasView(onProgress = { progress -> vm.onScratchProgressUpdate(progress, context) })
                        }
                    }
                }

                // New scratch button
                if (!vm.scratchDone) {
                    Text("🔄 New scratch card? Start over.", color = TextGray, fontSize = 13.sp,
                        modifier = Modifier.clickable { scratchKey++; vm.prepareScratch() })
                }

                // Tips card
                Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).border(1.5.dp, Border, RoundedCornerShape(14.dp)).background(White).padding(16.dp)) {
                    Column {
                        Text("💡 Tips", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        Spacer(Modifier.height(8.dp))
                        listOf(
                            "Use your finger to scratch the gray area",
                            "Scratch at least 40% to reveal the prize",
                            "Watch a short ad to claim your stars",
                            "Come back anytime for a new scratch card!"
                        ).forEach { tip ->
                            Row(modifier = Modifier.padding(bottom = 4.dp)) {
                                Text("•", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, modifier = Modifier.width(16.dp))
                                Text(tip, color = TextGray, fontSize = 13.sp, lineHeight = 19.sp)
                            }
                        }
                    }
                }
            }
        }

        // ── SCRATCH AD OVERLAY ───────────────────────────────────────────────
        if (vm.showScratchAd) {
            FullscreenAdOverlay(
                seconds = vm.scratchAdSeconds,
                phase = vm.scratchAdPhase,
                canClose = vm.scratchAdCanClose,
                onClose = { vm.closeScratchAd() }
            )
        }

        // ── SCRATCH RESULT POPUP ─────────────────────────────────────────────
        if (vm.showScratchResultPopup) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)).clickable { }, contentAlignment = Alignment.Center) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)
                        .clip(RoundedCornerShape(24.dp)).background(White).padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🎉", fontSize = 56.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Congratulations!", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                    Spacer(Modifier.height(8.dp))
                    Box(
                        modifier = Modifier.clip(RoundedCornerShape(50.dp))
                            .background(Brush.linearGradient(listOf(Purple, Pink)))
                            .padding(horizontal = 24.dp, vertical = 10.dp)
                    ) { Text("⭐ +${vm.formatCoin(vm.pendingScratchCoins)} Stars", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp) }
                    Spacer(Modifier.height(6.dp))
                    Text("You scratched the card successfully!", color = TextGray, fontSize = 14.sp)
                    Spacer(Modifier.height(20.dp))
                    Box(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50.dp))
                            .background(Brush.linearGradient(listOf(Purple, Pink)))
                            .clickable { vm.claimScratchResult(context); scratchKey++ },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🎉 Claim Stars!", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp,
                            modifier = Modifier.padding(vertical = 18.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("🔄 Scratch Again", color = Purple, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        modifier = Modifier.clickable { vm.prepareScratch(); scratchKey++ })
                }
            }
        }

        // ── AdMob Loading overlay (while real ad is preparing) ──────────────────
        if (vm.pendingAdSource == "scratch" && vm.showAdLoading) {
            AdLoadingOverlay()
        }

        // Toast
        ToastDisplay(vm = vm)
    }
}

// ─── Native Android Canvas for scratch ───────────────────────────────────────
@Composable
fun ScratchCanvasView(onProgress: (Float) -> Unit) {
    AndroidView(
        factory = { ctx ->
            object : View(ctx) {
                private var scratchBitmap: Bitmap? = null
                private var scratchCanvas: Canvas? = null
                private val erasePaint = Paint().apply {
                    alpha = 0; xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                    style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; strokeWidth = 60f
                }
                private val bgPaint = Paint().apply { color = android.graphics.Color.rgb(155, 89, 208) }
                private val textPaint = Paint().apply {
                    color = android.graphics.Color.WHITE; textAlign = Paint.Align.CENTER
                    typeface = Typeface.DEFAULT_BOLD; textSize = 48f
                }
                private var totalPixels = 0
                private var clearedPixels = 0

                override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
                    super.onSizeChanged(w, h, oldw, oldh)
                    if (w > 0 && h > 0) {
                        scratchBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        scratchCanvas = Canvas(scratchBitmap!!)
                        totalPixels = w * h
                        // Draw purple scratch layer
                        scratchCanvas!!.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)
                        // Draw hint text
                        scratchCanvas!!.drawText("👆 Scratch Here!", w / 2f, h / 2f - 10f, textPaint.apply { textSize = 42f })
                    }
                }

                override fun onDraw(canvas: Canvas) {
                    super.onDraw(canvas)
                    scratchBitmap?.let { canvas.drawBitmap(it, 0f, 0f, null) }
                }

                override fun onTouchEvent(event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                            scratchCanvas?.drawPoint(event.x, event.y, erasePaint)
                            invalidate()
                            // Count cleared pixels (sample every 20px)
                            val bmp = scratchBitmap ?: return true
                            var cleared = 0
                            val sampleStep = 20
                            for (x in 0 until bmp.width step sampleStep) {
                                for (y in 0 until bmp.height step sampleStep) {
                                    if (android.graphics.Color.alpha(bmp.getPixel(x, y)) == 0) cleared++
                                }
                            }
                            val sampledTotal = (bmp.width / sampleStep) * (bmp.height / sampleStep)
                            val progress = if (sampledTotal > 0) cleared.toFloat() / sampledTotal else 0f
                            onProgress(progress)
                        }
                    }
                    return true
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}
