package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import android.content.Intent
import android.net.Uri
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.*
import kotlinx.coroutines.delay

val QUIZ_GAME_LIST = listOf(
    Triple("1", "Qureka Live Quiz", "Play & win real cash"),
    Triple("2", "CashKaro Quiz", "Earn cashback & coins"),
    Triple("3", "Qureka Daily", "Daily quiz rewards"),
    Triple("4", "Meesho Quiz", "Win Meesho credits")
)

@Composable
fun QuizScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top bar with coin display
            Row(
                modifier = Modifier.fillMaxWidth()
                    .background(Brush.linearGradient(listOf(Purple, PurpleDark)))
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(White.copy(alpha = 0.2f)).clickable { onBack() }, contentAlignment = Alignment.Center) {
                    Text("←", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                }
                Spacer(Modifier.width(12.dp))
                Text("🧠 Quizzes & Games", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(White.copy(alpha = 0.2f)).padding(horizontal = 14.dp, vertical = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("⭐", fontSize = 16.sp); Spacer(Modifier.width(4.dp))
                        Text(vm.formatCoinShort(vm.coins), color = White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxSize().background(Color(0xFFf3f0ff))
                    .verticalScroll(rememberScrollState()).padding(bottom = 28.dp)
            ) {

                // ── QUIZ GAMES SECTION ─────────────────────────────────────
                Spacer(Modifier.height(16.dp))
                Text("🎮 Quiz Games", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 14.dp))
                Spacer(Modifier.height(4.dp))
                Text("Play 2 questions and earn ⭐ Stars!", color = TextGray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 14.dp))
                Spacer(Modifier.height(10.dp))

                QUIZ_GAME_LIST.forEach { (num, title, sub) ->
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.5.dp, Border, RoundedCornerShape(16.dp)).background(White)
                            .clickable { vm.openQuizWebview(num.toInt(), context) }.padding(16.dp)
                    ) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFf3e8ff)), contentAlignment = Alignment.Center) {
                                Text("🧠", fontSize = 26.sp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(title, color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                                Text(sub, color = TextGray, fontSize = 12.sp)
                            }
                            Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(Brush.linearGradient(listOf(Purple, Pink))).padding(horizontal = 14.dp, vertical = 8.dp)) {
                                Text("▶ Play", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                            }
                        }
                    }
                }

                // ── QUICK QUIZ SECTION ──────────────────────────────────────
                Spacer(Modifier.height(20.dp))
                Text("⚡ Quick Quiz", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 14.dp))
                Spacer(Modifier.height(4.dp))
                Text("Answer correctly to earn stars instantly!", color = TextGray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 14.dp))
                Spacer(Modifier.height(10.dp))

                val q = vm.quizQuestion
                if (q == null) {
                    Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp).clip(RoundedCornerShape(18.dp)).border(1.5.dp, Border, RoundedCornerShape(18.dp)).background(White).padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🧠", fontSize = 48.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("Ready to test your knowledge?", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, textAlign = TextAlign.Center)
                            Spacer(Modifier.height(4.dp))
                            Text("Answer correctly and earn ⭐ Stars!", color = TextGray, fontSize = 13.sp)
                            Spacer(Modifier.height(20.dp))
                            Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(Brush.linearGradient(listOf(Purple, Pink))).clickable { vm.prepareQuiz() }.padding(horizontal = 32.dp, vertical = 16.dp)) {
                                Text("🎯 Start Quiz", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            }
                        }
                    }
                } else {
                    // Quiz question card
                    Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp).clip(RoundedCornerShape(18.dp)).border(1.5.dp, Border, RoundedCornerShape(18.dp)).background(White).padding(18.dp)) {
                        Column {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(Color(0xFFf3e8ff)).padding(horizontal = 12.dp, vertical = 4.dp)) {
                                    Text("Question", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                                }
                                if (vm.quizAnswered) {
                                    Box(modifier = Modifier.clip(RoundedCornerShape(50.dp))
                                        .background(if (vm.quizResult == "correct") Color(0xFF22c55e) else Color(0xFFef4444))
                                        .padding(horizontal = 12.dp, vertical = 4.dp)) {
                                        Text(if (vm.quizResult == "correct") "✅ Correct!" else "❌ Wrong!", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Text(q.question, color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, lineHeight = 24.sp)
                            Spacer(Modifier.height(14.dp))

                            q.options.forEachIndexed { idx, opt ->
                                val isSelected = vm.quizSelectedOption == idx
                                val isCorrect = vm.quizAnswered && idx == q.answer
                                val isWrong = vm.quizAnswered && isSelected && idx != q.answer
                                val bgColor = when { isCorrect -> Color(0xFF22c55e); isWrong -> Color(0xFFef4444); isSelected -> Purple; else -> Color(0xFFf3f0ff) }
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.5.dp, if (isSelected || isCorrect) Color.Transparent else Border, RoundedCornerShape(12.dp))
                                        .background(bgColor)
                                        .clickable(enabled = !vm.quizAnswered) { vm.answerQuiz(context, idx) }
                                        .padding(horizontal = 16.dp, vertical = 14.dp)
                                ) {
                                    Text(opt, color = if (isSelected || isCorrect || isWrong) White else TextDark, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                            if (vm.quizAnswered) {
                                Spacer(Modifier.height(14.dp))
                                Box(
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50.dp))
                                        .background(Brush.linearGradient(listOf(Purple, Pink)))
                                        .clickable { vm.nextQuizQuestion() }.padding(vertical = 14.dp),
                                    contentAlignment = Alignment.Center
                                ) { Text("▶ Next Question", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
                            }
                        }
                    }
                }

                // ── QUREKA PROMO SECTION ────────────────────────────────────
                Spacer(Modifier.height(20.dp))
                Box(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF1a0533), Color(0xFF2d0a5e), Color(0xFF4a1fa8))))
                        .padding(20.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🎯", fontSize = 32.sp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("QUREKA", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                                Text("India's #1 Quiz App", color = White.copy(alpha = 0.8f), fontSize = 13.sp)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            listOf("1 Cr+\nwinners", "308K+\ndaily points", "100%\nfree").forEach { stat ->
                                val lines = stat.split("\n")
                                Box(modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(White.copy(alpha = 0.15f)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(lines[0], color = White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                        Text(lines[1], color = White.copy(alpha = 0.75f), fontSize = 11.sp, textAlign = TextAlign.Center)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Test Your Knowledge: Play GK, Sports, Business, Science & Mega Quizzes to win 💰", color = White.copy(alpha = 0.9f), fontSize = 13.sp, lineHeight = 20.sp)
                        Spacer(Modifier.height(14.dp))
                        Box(
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50.dp))
                                .background(Brush.linearGradient(listOf(Pink, Color(0xFFf59e0b))))
                                .clickable { vm.openQuizWebview(1, context) }.padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("🎯 Claim Free Code", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
                    }
                }
            }
        }

        // ── QUIZ WEBVIEW OVERLAY ─────────────────────────────────────────────
        if (vm.showQuizWebview) {
            QuizWebviewOverlay(vm = vm)
        }

        // Toast
        ToastDisplay(vm = vm)
    }
}

// ─── Quiz Webview Overlay ─────────────────────────────────────────────────────
@Composable
fun BoxScope.QuizWebviewOverlay(vm: AppViewModel) {
    val context = LocalContext.current

    LaunchedEffect(vm.qwvShowRedirect) {
        if (!vm.qwvShowRedirect && vm.qwvSiteUrl.isNotEmpty()) {
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://${vm.qwvSiteUrl}")))
            } catch (e: Exception) {}
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.White)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(modifier = Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Purple, PurpleDark))).padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(White.copy(alpha = 0.2f)).clickable { vm.closeQuizWebview() }, contentAlignment = Alignment.Center) {
                    Text("✕", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Game ${vm.qwvGameNum}", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text(vm.qwvSiteUrl, color = White.copy(alpha = 0.75f), fontSize = 12.sp)
                }
                Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(White.copy(alpha = 0.2f)).padding(horizontal = 14.dp, vertical = 6.dp)) {
                    Text("⭐ ${vm.formatCoinShort(vm.coins)}", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
            }

            Column(modifier = Modifier.fillMaxSize().background(Color(0xFF1a0533)).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {

                // Redirect countdown
                if (vm.qwvShowRedirect) {
                    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(White.copy(alpha = 0.1f)).border(1.dp, White.copy(alpha = 0.2f), RoundedCornerShape(14.dp)).padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Redirecting to ${vm.qwvSiteUrl} in ${vm.qwvRedirectSec}s...", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(Purple).clickable { vm.skipQwvRedirect() }.padding(horizontal = 12.dp, vertical = 6.dp)) {
                                Text("Skip →", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Intro
                Text("Let's get started,", color = White.copy(alpha = 0.8f), fontSize = 15.sp)
                Text("answer 2 simple questions to earn Stars now:", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)

                // Q1
                val q1 = vm.qwvQ1
                if (q1 != null) {
                    WebviewQuestion(question = q1, answered = vm.qwvQ1Answered, selectedOpt = vm.qwvQ1SelectedOpt, onAnswer = { vm.answerQwvQ1(it, context) })
                }

                // Q2 (after Q1 answered)
                val q2 = vm.qwvQ2
                if (q2 != null && vm.qwvQ1Answered) {
                    WebviewQuestion(question = q2, answered = vm.qwvQ2Answered, selectedOpt = vm.qwvQ2SelectedOpt, onAnswer = { vm.answerQwvQ2(it, context) })
                }

                // Done state
                if (vm.qwvDone) {
                    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xFF6d28d9), Color(0xFF9b59d0)))).padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🎉", fontSize = 48.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Congratulations!", color = Color(0xFFffd600), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                            Text("⭐ +${vm.formatCoin(vm.qwvEarned)} Stars Earned!", color = White.copy(alpha = 0.9f), fontSize = 16.sp)
                            Spacer(Modifier.height(16.dp))
                            Box(modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(White).clickable { vm.closeQuizWebview() }.padding(horizontal = 32.dp, vertical = 14.dp)) {
                                Text("✅ Back to App", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            }
                        }
                    }
                }

                // Footer
                Spacer(Modifier.height(8.dp))
                Text("By proceeding, you agree to our Terms of Use & Privacy Policy", color = White.copy(alpha = 0.5f), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

// ─── Webview Question Card ────────────────────────────────────────────────────
@Composable
fun WebviewQuestion(question: QuizQuestion, answered: Boolean, selectedOpt: Int, onAnswer: (Int) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).border(1.5.dp, White.copy(alpha = 0.2f), RoundedCornerShape(16.dp)).background(White.copy(alpha = 0.1f)).padding(18.dp)) {
        Text(question.question, color = White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, lineHeight = 22.sp)
        Spacer(Modifier.height(12.dp))
        question.options.forEachIndexed { idx, opt ->
            val isSelected = selectedOpt == idx
            val isCorrect = answered && idx == question.answer
            val isWrong = answered && isSelected && idx != question.answer
            val bg = when { isCorrect -> Color(0xFF22c55e); isWrong -> Color(0xFFef4444); isSelected -> Purple; else -> White.copy(alpha = 0.15f) }
            Box(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(bg)
                    .clickable(enabled = !answered) { onAnswer(idx) }.padding(horizontal = 16.dp, vertical = 13.dp)
            ) {
                Text(opt, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}
