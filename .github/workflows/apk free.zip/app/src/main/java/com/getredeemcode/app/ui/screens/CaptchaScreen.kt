package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel
import kotlinx.coroutines.delay

@Composable
fun CaptchaScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            ScreenTopBar("🤖 Recaptcha", vm.formatCoinShort(vm.coins), onBack)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFf3f0ff))
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Daily limit indicator
                val remaining = (vm.CAPTCHA_DAILY_LIMIT - vm.captchaUsedToday).coerceAtLeast(0)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFf3e8ff))
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📊", fontSize = 20.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Daily Captchas: $remaining / ${vm.CAPTCHA_DAILY_LIMIT} remaining", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                            Text("Earn up to 2.00 ⭐ per captcha", color = TextGray, fontSize = 12.sp)
                        }
                    }
                }

                if (vm.captchaLimitReached) {
                    // Daily limit reached
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color(0xFFfef3c7))
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("⏰", fontSize = 48.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Daily Limit Reached!", color = Color(0xFF92400e), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Spacer(Modifier.height(6.dp))
                            Text("Come back tomorrow for more captchas!", color = Color(0xFF92400e), fontSize = 14.sp, textAlign = TextAlign.Center)
                        }
                    }
                } else {
                    // Instructions
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1a73e8).copy(alpha = 0.08f))
                            .border(1.dp, Color(0xFF1a73e8).copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("ℹ️", fontSize = 18.sp)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "Type the characters exactly as shown in the image below.",
                                color = Color(0xFF1a73e8), fontSize = 13.sp, fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Captcha image box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(2.dp, Border, RoundedCornerShape(16.dp))
                            .background(
                                Brush.linearGradient(listOf(
                                    Color(0xFFece9f5), Color(0xFFf3e8ff), Color(0xFFfce7f3)
                                ))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        // Render captcha text with visual noise
                        CaptchaTextDisplay(captchaText = vm.captchaText)
                    }

                    // Input field
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text("Enter the characters above:", color = TextDark, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = vm.captchaInput,
                            onValueChange = { vm.captchaInput = it; vm.captchaError = false },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Type captcha here...", color = TextGray) },
                            isError = vm.captchaError,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { vm.submitCaptcha(context) }),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Purple,
                                unfocusedBorderColor = Border,
                                errorBorderColor = Color(0xFFef4444)
                            )
                        )
                        if (vm.captchaError) {
                            Spacer(Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("❌", fontSize = 14.sp)
                                Spacer(Modifier.width(6.dp))
                                Text("Enter Correct Captcha", color = Color(0xFFef4444), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Submit button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(50.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF1a73e8), Color(0xFF42a5f5))))
                            .clickable { vm.submitCaptcha(context) }
                            .padding(vertical = 18.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("✅ Submit Captcha", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }

                    // New captcha link
                    Text(
                        "🔄 Generate new captcha",
                        color = Purple, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        modifier = Modifier.clickable { vm.generateCaptchaText() }
                    )
                }
            }
        }

        // WIN OVERLAY
        if (vm.showCaptchaWin) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)).clickable { }, contentAlignment = Alignment.Center) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 28.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(White)
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🎉", fontSize = 56.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("You Won!", color = TextDark, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                    Spacer(Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50.dp))
                            .background(Brush.linearGradient(listOf(Purple, Pink)))
                            .padding(horizontal = 24.dp, vertical = 10.dp)
                    ) { Text("⭐ +${vm.formatCoin(vm.pendingCaptchaCoins)} Stars", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp) }
                    Spacer(Modifier.height(6.dp))
                    Text("Great job solving the captcha!", color = TextGray, fontSize = 14.sp)
                    Spacer(Modifier.height(20.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(50.dp))
                            .background(Brush.linearGradient(listOf(Purple, Pink)))
                            .clickable { vm.claimCaptchaWin(context) }
                            .padding(vertical = 18.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("🎉 Claim Stars!", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
                }
            }
        }

        // ── AdMob Loading overlay ─────────────────────────────────────────────
        if (vm.pendingAdSource == "captcha" && vm.showAdLoading) {
            AdLoadingOverlay()
        }

        // TOAST
        ToastDisplay(vm = vm)
    }
}

@Composable
fun CaptchaTextDisplay(captchaText: String) {
    // Draw captcha characters with varied rotation and color for visual effect
    Row(
        horizontalArrangement = Arrangement.spacedBy((-2).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val colors = listOf(
            Color(0xFF4a1fa8), Color(0xFF1a73e8), Color(0xFFc62828),
            Color(0xFF2e7d32), Color(0xFF6d28d9), Color(0xFF0077b6)
        )
        captchaText.forEachIndexed { idx, char ->
            val strikethrough = idx == 1 || idx == captchaText.length - 2
            Text(
                text = char.toString(),
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = colors[idx % colors.size],
                textDecoration = if (strikethrough) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
            )
        }
    }
}
