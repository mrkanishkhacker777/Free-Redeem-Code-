package com.getredeemcode.app.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

// ─── AdMob IDs ────────────────────────────────────────────────────────────────
object AdConstants {
    const val APP_ID = "ca-app-pub-2366599730777996~6682788999"

    // PRIMARY Ad Unit ID — Always use this first
    const val REWARDED_AD_ID_PRIMARY = "ca-app-pub-2366599730777996/9102809483"

    // BACKUP Ad Unit ID — Only used when primary fails to load/show
    // Screenshot se mila naya rewarded ad unit: 9820005102
    const val REWARDED_AD_ID_BACKUP = "ca-app-pub-2366599730777996/9820005102"

    // Test ID — use during development only (uncomment if needed)
    // const val REWARDED_AD_ID_PRIMARY = "ca-app-pub-3940256099942544/5224354917"
}

// ─── Ad Load State ────────────────────────────────────────────────────────────
enum class AdState {
    IDLE, LOADING, LOADED, SHOWING, FAILED
}

// ─── Ad Manager Singleton ─────────────────────────────────────────────────────
object AdManager {

    private const val TAG = "AdManager"

    private var rewardedAd: RewardedAd? = null
    private var isInitialized = false

    // Track which ID is currently loaded — primary or backup
    private var isUsingBackupId = false
    // How many times primary has consecutively failed
    private var primaryFailCount = 0

    private val _adState = MutableStateFlow(AdState.IDLE)
    val adState: StateFlow<AdState> = _adState

    // Callback after ad closes — called with (earnedReward: Boolean)
    private var onAdClosed: ((Boolean) -> Unit)? = null

    // ── Init MobileAds (call once from MainActivity) ──────────────────────────
    fun initialize(context: Context) {
        if (isInitialized) return
        isInitialized = true
        MobileAds.initialize(context) {
            Log.d(TAG, "MobileAds initialized")
            // Always start loading with PRIMARY ID
            loadRewardedAd(context, useBackup = false)
        }
    }

    // ── Load a Rewarded Ad ────────────────────────────────────────────────────
    // useBackup = true → force backup ID, false → use primary (default)
    fun loadRewardedAd(context: Context, useBackup: Boolean = false) {
        if (_adState.value == AdState.LOADING || _adState.value == AdState.LOADED) return
        _adState.value = AdState.LOADING

        // Decide which ID to use
        val adUnitId = if (useBackup) {
            isUsingBackupId = true
            Log.w(TAG, "Loading BACKUP ad ID (primary failed $primaryFailCount times)")
            AdConstants.REWARDED_AD_ID_BACKUP
        } else {
            isUsingBackupId = false
            Log.d(TAG, "Loading PRIMARY ad ID...")
            AdConstants.REWARDED_AD_ID_PRIMARY
        }

        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    _adState.value = AdState.LOADED
                    // Primary loaded successfully → reset fail counter
                    if (!isUsingBackupId) primaryFailCount = 0
                    Log.d(TAG, "Rewarded ad loaded ✅ [${if (isUsingBackupId) "BACKUP" else "PRIMARY"}]")
                    setupFullScreenCallback(context)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    _adState.value = AdState.FAILED
                    Log.e(TAG, "Ad failed to load [${if (isUsingBackupId) "BACKUP" else "PRIMARY"}]: ${error.message}")

                    if (!isUsingBackupId) {
                        // Primary failed → try backup once
                        primaryFailCount++
                        Log.w(TAG, "Primary failed. Trying BACKUP ID...")
                        loadRewardedAd(context, useBackup = true)
                    } else {
                        // Backup also failed → stay FAILED, don't retry immediately
                        Log.e(TAG, "Both PRIMARY and BACKUP failed to load.")
                        isUsingBackupId = false // Reset for next attempt
                    }
                }
            }
        )
    }

    // ── Setup FullScreen Callbacks ────────────────────────────────────────────
    private fun setupFullScreenCallback(context: Context) {
        rewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                _adState.value = AdState.SHOWING
                Log.d(TAG, "Ad showing fullscreen [${if (isUsingBackupId) "BACKUP" else "PRIMARY"}]")
            }

            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "Ad dismissed")
                rewardedAd = null
                _adState.value = AdState.IDLE
                // Next time load PRIMARY again (fresh start)
                loadRewardedAd(context, useBackup = false)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.e(TAG, "Ad failed to show: ${error.message}")
                rewardedAd = null
                _adState.value = AdState.FAILED
                onAdClosed?.invoke(false)
                onAdClosed = null
                // Try primary first for reload
                loadRewardedAd(context, useBackup = false)
            }
        }
    }

    // ── Show Rewarded Ad ──────────────────────────────────────────────────────
    // Returns true if ad was shown, false if not available (triggers fallback overlay)
    fun showRewardedAd(
        activity: Activity,
        onRewarded: (Boolean) -> Unit   // true = user earned reward
    ): Boolean {
        val ad = rewardedAd
        if (ad == null || _adState.value != AdState.LOADED) {
            Log.w(TAG, "Ad not ready, state=${_adState.value}")
            onRewarded(false)
            // Try loading — primary first, then backup if primary fails (handled inside)
            loadRewardedAd(activity, useBackup = false)
            return false
        }

        onAdClosed = onRewarded
        var rewardGranted = false

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                _adState.value = AdState.SHOWING
                Log.d(TAG, "Ad showing [${if (isUsingBackupId) "BACKUP" else "PRIMARY"}]")
            }

            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "Ad dismissed, reward=$rewardGranted")
                rewardedAd = null
                _adState.value = AdState.IDLE
                onAdClosed?.invoke(rewardGranted)
                onAdClosed = null
                // Pre-load next ad — always start with primary
                loadRewardedAd(activity, useBackup = false)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.e(TAG, "Failed to show: ${error.message}")
                rewardedAd = null
                _adState.value = AdState.FAILED
                onAdClosed?.invoke(false)
                onAdClosed = null
                // Reload — primary first
                loadRewardedAd(activity, useBackup = false)
            }
        }

        ad.show(activity) { rewardItem ->
            // User earned the reward
            rewardGranted = true
            Log.d(TAG, "Reward earned: ${rewardItem.amount} ${rewardItem.type}")
        }
        return true
    }

    // ── Is Ad Ready ──────────────────────────────────────────────────────────
    fun isAdReady(): Boolean = rewardedAd != null && _adState.value == AdState.LOADED
}
