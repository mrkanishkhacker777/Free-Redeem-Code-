package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onScratch: () -> Unit,
    onQuiz: () -> Unit,
    onCaptcha: () -> Unit,
    onRedeem: () -> Unit,
    onRefer: () -> Unit,
    onPrivacy: () -> Unit,
    onTerms: () -> Unit
) {
    val context = LocalContext.current
    var showTopUp by remember { mutableStateOf(false) }

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.linearGradient(listOf(CardBg, CardBg2)))
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Get Redeem Code", color = TextWhite, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text("Complete tasks & earn!", color = PurpleLight, fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Coin balance
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50.dp))
                            .background(Brush.linearGradient(listOf(Gold, GoldDark)))
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("🪙 ${vm.coins.toInt()}", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    // Top-Up button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50.dp))
                            .background(Brush.linearGradient(listOf(Green, Cyan)))
                            .clickable { showTopUp = true }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("⚡ Top-Up", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Welcome bonus card
                if (!vm.bonusClaimed) {
                    GradientCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = listOf(Color(0xFF065F46), Color(0xFF064E3B)),
                        borderColor = Green.copy(alpha = 0.5f)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("🎉 Welcome Bonus!", color = GreenLight, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("Claim your free 50 coins now!", color = TextGray, fontSize = 14.sp)
                            }
                            GradientButton(
                                text = "Claim",
                                emoji = "🎁",
                                onClick = { vm.claimBonus(context) },
                                colors = listOf(Green, GreenLight),
                                fontSize = 14
                            )
                        }
                    }
                }

                // Stats row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(modifier = Modifier.weight(1f), emoji = "🪙", value = "${vm.coins.toInt()}", label = "Total Coins")
                    StatCard(modifier = Modifier.weight(1f), emoji = "👥", value = "${vm.referStats.size}", label = "Referrals")
                }

                // Section title
                Text("💼 Earn Coins", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)

                // Task cards
                TaskCard(
                    emoji = "🎰",
                    title = "Scratch & Win",
                    subtitle = "Scratch to reveal up to 100 coins!",
                    reward = "+5 to +100",
                    gradientColors = listOf(Color(0xFF6D28D9), Color(0xFF7C3AED)),
                    onClick = { vm.prepareScratch(); onScratch() }
                )
                TaskCard(
                    emoji = "🧠",
                    title = "Quiz Time",
                    subtitle = "Answer correctly, earn 10 coins!",
                    reward = "+10",
                    gradientColors = listOf(Color(0xFF0E7490), Color(0xFF0891B2)),
                    onClick = { vm.prepareQuiz(); onQuiz() }
                )
                TaskCard(
                    emoji = "🔢",
                    title = "Captcha Verify",
                    subtitle = "Solve the math, earn 5 coins!",
                    reward = "+5",
                    gradientColors = listOf(Color(0xFF065F46), Color(0xFF047857)),
                    onClick = { vm.generateCaptcha(); onCaptcha() }
                )

                // Divider
                Divider(color = Purple.copy(alpha = 0.2f), thickness = 1.dp)

                // Referral
                Text("👥 Invite & Earn", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                TaskCard(
                    emoji = "🤝",
                    title = "Refer & Earn",
                    subtitle = "Share your code, get +20 per referral!",
                    reward = "+20",
                    gradientColors = listOf(Color(0xFF92400E), Color(0xFFB45309)),
                    onClick = onRefer
                )

                // Divider
                Divider(color = Purple.copy(alpha = 0.2f), thickness = 1.dp)

                // Redeem section
                Text("🎁 Redeem Codes", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)

                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf(
                            Triple(1000, "₹10 Code", listOf(Purple, PurpleLight)),
                            Triple(1650, "₹20 Code", listOf(Blue, Cyan)),
                            Triple(2000, "₹50 Code", listOf(Gold, GoldDark))
                        ).forEach { (cost, label, colors) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(label, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text("Costs $cost coins", color = TextMuted, fontSize = 13.sp)
                                }
                                val canAfford = vm.coins >= cost
                                GradientButton(
                                    text = if (canAfford) "Redeem" else "Need ${cost - vm.coins.toInt()} more",
                                    onClick = onRedeem,
                                    colors = colors,
                                    enabled = canAfford,
                                    fontSize = 13
                                )
                            }
                            if (cost != 2000) Divider(color = Purple.copy(alpha = 0.15f))
                        }
                    }
                }

                // Footer links
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onPrivacy) {
                        Text("Privacy Policy", color = PurpleLight, fontSize = 13.sp)
                    }
                    Text("•", color = TextMuted, fontSize = 13.sp)
                    TextButton(onClick = onTerms) {
                        Text("Terms", color = PurpleLight, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Top-Up overlay
        if (showTopUp) {
            TopUpOverlay(
                vm = vm,
                onDismiss = { showTopUp = false }
            )
        }
    }
}

@Composable
fun StatCard(modifier: Modifier = Modifier, emoji: String, value: String, label: String) {
    GradientCard(modifier = modifier) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(emoji, fontSize = 28.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = TextWhite, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            Text(label, color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
fun TaskCard(
    emoji: String,
    title: String,
    subtitle: String,
    reward: String,
    gradientColors: List<Color>,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(gradientColors))
            .clickable(onClick = onClick)
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(emoji, fontSize = 36.sp)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(subtitle, color = TextWhite.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(reward, color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text("coins", color = TextWhite.copy(alpha = 0.7f), fontSize = 11.sp)
            }
        }
    }
}
