package com.getredeemcode.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Purple = Color(0xFF7C3AED)
val PurpleLight = Color(0xFFA78BFA)
val PurpleDark = Color(0xFF5B21B6)
val Pink = Color(0xFFEC4899)
val PinkLight = Color(0xFFF9A8D4)
val Yellow = Color(0xFFF59E0B)
val Green = Color(0xFF10B981)
val GreenLight = Color(0xFF34D399)
val Red = Color(0xFFEF4444)
val RedLight = Color(0xFFFCA5A5)
val Blue = Color(0xFF3B82F6)
val DarkBg = Color(0xFF0F0820)
val CardBg = Color(0xFF1A0D35)
val CardBg2 = Color(0xFF2D1B69)
val TextWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFFD1D5DB)
val TextMuted = Color(0xFF9CA3AF)
val Gold = Color(0xFFFFD700)
val GoldDark = Color(0xFFFF8C00)
val Orange = Color(0xFFF97316)
val Cyan = Color(0xFF06B6D4)

private val ColorScheme = darkColorScheme(
    primary = Purple,
    onPrimary = TextWhite,
    secondary = Pink,
    onSecondary = TextWhite,
    background = DarkBg,
    onBackground = TextWhite,
    surface = CardBg,
    onSurface = TextWhite,
    error = Red,
    onError = TextWhite
)

@Composable
fun GetRedeemCodeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ColorScheme,
        typography = Typography(),
        content = content
    )
}
