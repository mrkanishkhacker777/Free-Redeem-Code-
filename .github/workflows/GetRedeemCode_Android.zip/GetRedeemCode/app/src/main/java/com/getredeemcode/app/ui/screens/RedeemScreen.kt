package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel

@Composable
fun RedeemScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    var selectedTier by remember { mutableStateOf(1000) }

    val tiers = listOf(
        Triple(1000, "₹10 Code", listOf(Purple, PurpleLight)),
        Triple(1650, "₹20 Code", listOf(Blue, Cyan)),
        Triple(2000, "₹50 Code", listOf(Gold, GoldDark))
    )

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            TopBar(title = "🎁 Redeem Code", onBack = onBack, coins = vm.coins)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                // Balance card
                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Your Balance", color = TextGray, fontSize = 13.sp)
                            Text("${vm.coins.toInt()} Coins", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
                        }
                        Text("🪙", fontSize = 48.sp)
                    }
                }

                // Tier selector
                Text("Select Reward Tier", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)

                tiers.forEach { (tierCoins, label, colors) ->
                    val isSelected = selectedTier == tierCoins
                    val canAfford = vm.coins >= tierCoins

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isSelected) Brush.linearGradient(colors.map { it.copy(0.25f) })
                                else Brush.linearGradient(listOf(CardBg, CardBg2))
                            )
                            .border(
                                2.dp,
                                if (isSelected) colors.first() else Purple.copy(0.3f),
                                RoundedCornerShape(16.dp)
                            )
                            .clickable { selectedTier = tierCoins }
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedTier = tierCoins },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = colors.first(),
                                        unselectedColor = TextMuted
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(label, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text("$tierCoins coins required", color = TextMuted, fontSize = 13.sp)
                                }
                            }
                            if (canAfford) {
                                InfoBadge("✓ Eligible", color = Green)
                            } else {
                                InfoBadge("Need ${tierCoins - vm.coins.toInt()} more", color = Red)
                            }
                        }
                    }
                }

                // UTR input
                Text("Enter UTR Number", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)

                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Text("What is UTR?", color = TextGray, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "UTR (Unique Transaction Reference) is a 12-digit number found in your UPI payment receipt after sending money.",
                        color = TextMuted,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }

                OutlinedTextField(
                    value = vm.redeemUtr,
                    onValueChange = {
                        vm.redeemUtr = it
                        vm.redeemMsg = ""
                        vm.redeemError = false
                        vm.redeemSuccess = false
                    },
                    placeholder = { Text("Enter 12-digit UTR number", color = TextMuted) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedBorderColor = if (vm.redeemError) Red else Purple,
                        unfocusedBorderColor = if (vm.redeemError) Red.copy(0.5f) else Purple.copy(0.3f),
                        cursorColor = Purple,
                        focusedContainerColor = CardBg2.copy(alpha = 0.3f),
                        unfocusedContainerColor = CardBg2.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    isError = vm.redeemError
                )

                if (vm.redeemMsg.isNotEmpty()) {
                    GradientCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = if (vm.redeemSuccess)
                            listOf(Color(0xFF065F46), Color(0xFF047857))
                        else
                            listOf(Color(0xFF1F0A0A), Color(0xFF2D1010)),
                        borderColor = if (vm.redeemSuccess) Green.copy(0.4f) else Red.copy(0.3f)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (vm.redeemSuccess) {
                                Text("🎉 Success!", color = GreenLight, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Your Redeem Code:", color = TextGray, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Brush.linearGradient(listOf(Purple, Pink)))
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        vm.redeemCode,
                                        color = TextWhite,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 22.sp,
                                        letterSpacing = 2.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Copy this code and use it in your app!", color = GreenLight, fontSize = 13.sp)
                            } else {
                                Text(vm.redeemMsg, color = RedLight, fontSize = 14.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }

                val canAffordSelected = vm.coins >= selectedTier
                GradientButton(
                    text = if (canAffordSelected) "Get Redeem Code" else "Insufficient Coins",
                    emoji = if (canAffordSelected) "🎁" else "🔒",
                    onClick = { vm.submitRedeem(context, selectedTier) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = canAffordSelected && vm.redeemUtr.isNotBlank(),
                    fontSize = 17
                )

                // Disclaimer
                GradientCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = listOf(Color(0xFF1C1008), Color(0xFF2D1A08)),
                    borderColor = Yellow.copy(0.3f)
                ) {
                    Text("⚠️ Important", color = Yellow, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    listOf(
                        "Each UTR can only be used once",
                        "Codes are valid for 24 hours",
                        "Screenshot your code immediately",
                        "Payments are non-refundable"
                    ).forEach { info ->
                        Row(modifier = Modifier.padding(vertical = 2.dp)) {
                            Text("• ", color = Yellow, fontSize = 13.sp)
                            Text(info, color = TextGray, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
