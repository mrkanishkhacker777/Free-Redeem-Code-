package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel

@Composable
fun ScratchScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current

    // Canvas scratch state
    var scratchedPoints by remember { mutableStateOf(listOf<Offset>()) }
    var revealed by remember { mutableStateOf(false) }
    val prize = vm.scratchPrize

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            TopBar(title = "🎰 Scratch & Win", onBack = onBack, coins = vm.coins)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Scratch to Reveal!", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Scratch the card below to reveal your prize", color = TextGray, fontSize = 14.sp, textAlign = TextAlign.Center)
                    }
                }

                // Scratch card
                Box(
                    modifier = Modifier
                        .size(280.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF6D28D9), Color(0xFF7C3AED), Color(0xFFEC4899))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    // Prize underneath
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Text(
                            if (prize?.coins == 0.0) "😔" else "🪙",
                            fontSize = 56.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            prize?.label ?: "???",
                            color = if (prize?.coins == 0.0) TextGray else Gold,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 32.sp
                        )
                        if ((prize?.coins ?: 0.0) > 0) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Coins Won!", color = GreenLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Scratch overlay
                    if (!revealed) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDrag = { change, _ ->
                                            scratchedPoints = scratchedPoints + change.position
                                            val progress = (scratchedPoints.size.toFloat() / 300f).coerceIn(0f, 1f)
                                            vm.updateScratchProgress(progress)
                                            if (progress >= 0.6f && !revealed) {
                                                revealed = true
                                                vm.revealScratch(context)
                                            }
                                        }
                                    )
                                }
                        ) {
                            drawRect(
                                Brush.linearGradient(
                                    listOf(Color(0xFFB45309), Color(0xFF92400E))
                                ),
                                size = size
                            )
                            // Draw scratch marks as circles
                            scratchedPoints.forEach { point ->
                                drawCircle(
                                    color = Color.Transparent,
                                    radius = 30f,
                                    center = point,
                                    blendMode = BlendMode.Clear
                                )
                            }
                            // Hint text
                            if (scratchedPoints.isEmpty()) {
                                drawContext.canvas.nativeCanvas.drawText(
                                    "👆 Scratch Here!",
                                    size.width / 2,
                                    size.height / 2,
                                    android.graphics.Paint().apply {
                                        color = android.graphics.Color.WHITE
                                        textSize = 44f
                                        textAlign = android.graphics.Paint.Align.CENTER
                                    }
                                )
                            }
                        }
                    }
                }

                // Progress
                if (!revealed) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "${(vm.scratchProgress * 100).toInt()}% scratched",
                            color = TextGray,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { vm.scratchProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = Purple,
                            trackColor = Purple.copy(alpha = 0.2f)
                        )
                    }
                }

                // Result
                if (revealed && prize != null) {
                    GradientCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = if (prize.coins > 0)
                            listOf(Color(0xFF065F46), Color(0xFF047857))
                        else
                            listOf(Color(0xFF1F0A0A), Color(0xFF2D1010)),
                        borderColor = if (prize.coins > 0) Green.copy(0.4f) else Red.copy(0.3f)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (prize.coins > 0) "🎉 You Won!" else "Better luck next time!",
                                color = if (prize.coins > 0) GreenLight else TextGray,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            )
                            if (prize.coins > 0) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("+${prize.coins.toInt()} coins added!", color = GreenLight, fontSize = 15.sp)
                            }
                        }
                    }

                    GradientButton(
                        text = "Scratch Again",
                        emoji = "🔄",
                        onClick = {
                            scratchedPoints = emptyList()
                            revealed = false
                            vm.prepareScratch()
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Prize table
                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Prize Table", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    listOf(
                        "🪙 +5 Coins" to "Common",
                        "🪙 +10 Coins" to "Uncommon",
                        "🪙 +20 Coins" to "Rare",
                        "🪙 +50 Coins" to "Epic",
                        "🪙 +100 Coins" to "Legendary"
                    ).forEach { (prize, rarity) ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(prize, color = TextGray, fontSize = 14.sp)
                            InfoBadge(rarity, color = Purple)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
