package com.getredeemcode.app.viewmodel

import android.content.Context
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.getredeemcode.app.data.AppDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.random.Random

// ─── Redeem Code Pools ───────────────────────────────────────────────────────
val CODES_1000 = listOf(
    "RC1000-AAAA","RC1000-BBBB","RC1000-CCCC","RC1000-DDDD","RC1000-EEEE",
    "RC1000-FFFF","RC1000-GGGG","RC1000-HHHH","RC1000-IIII","RC1000-JJJJ"
)
val CODES_1650 = listOf(
    "RC1650-AAAA","RC1650-BBBB","RC1650-CCCC","RC1650-DDDD","RC1650-EEEE"
)
val CODES_2000 = listOf(
    "RC2000-AAAA","RC2000-BBBB","RC2000-CCCC","RC2000-DDDD","RC2000-EEEE"
)

// ─── Quiz Data ────────────────────────────────────────────────────────────────
data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val answer: Int
)

val QUIZ_QUESTIONS = listOf(
    QuizQuestion("India ki capital kya hai?", listOf("Mumbai","New Delhi","Kolkata","Chennai"), 1),
    QuizQuestion("2 + 2 = ?", listOf("3","4","5","6"), 1),
    QuizQuestion("Suraj kis disha mein ugta hai?", listOf("Paschim","Uttar","Purb","Dakshin"), 2),
    QuizQuestion("Paani ka sutra kya hai?", listOf("CO2","H2O","O2","NaCl"), 1),
    QuizQuestion("Hamare solar system mein kitne grah hain?", listOf("7","8","9","10"), 1),
    QuizQuestion("Manav sharir mein kitni haddiyaan hoti hain?", listOf("205","206","207","208"), 1),
    QuizQuestion("IPL ka full form kya hai?", listOf("Indian Premier League","International Premier League","Indian Power League","Indian Play League"), 0),
    QuizQuestion("Bharat mein kitne rajya hain?", listOf("26","27","28","29"), 2),
    QuizQuestion("Sabse bada grah kaun sa hai?", listOf("Saturn","Jupiter","Uranus","Neptune"), 1),
    QuizQuestion("'Jai Hind' kisne kaha tha?", listOf("Gandhi ji","Nehru ji","Subhas Chandra Bose","Bhagat Singh"), 2)
)

// ─── Scratch Prize Config ─────────────────────────────────────────────────────
data class ScratchPrize(val label: String, val coins: Double, val weight: Int)

val SCRATCH_PRIZES = listOf(
    ScratchPrize("₹0", 0.0, 40),
    ScratchPrize("+5 Coins", 5.0, 25),
    ScratchPrize("+10 Coins", 10.0, 20),
    ScratchPrize("+20 Coins", 20.0, 10),
    ScratchPrize("+50 Coins", 50.0, 4),
    ScratchPrize("+100 Coins", 100.0, 1)
)

fun pickScratchPrize(): ScratchPrize {
    val total = SCRATCH_PRIZES.sumOf { it.weight }
    var r = Random.nextInt(total)
    for (p in SCRATCH_PRIZES) {
        r -= p.weight
        if (r < 0) return p
    }
    return SCRATCH_PRIZES.first()
}

// ─── Refer Stats ──────────────────────────────────────────────────────────────
data class ReferEntry(val code: String, val coins: Double)

class AppViewModel : ViewModel() {

    // ── State ──────────────────────────────────────────────────────────────────
    var coins by mutableStateOf(0.0)
    var bonusClaimed by mutableStateOf(false)
    var isLoaded by mutableStateOf(false)

    // Scratch
    var scratchRevealed by mutableStateOf(false)
    var scratchPrize by mutableStateOf<ScratchPrize?>(null)
    var scratchProgress by mutableStateOf(0f)

    // Quiz
    var quizQuestion by mutableStateOf<QuizQuestion?>(null)
    var quizAnswered by mutableStateOf(false)
    var quizSelectedOption by mutableStateOf(-1)
    var quizResult by mutableStateOf("") // "correct" | "wrong"

    // Captcha
    var captchaAnswer by mutableStateOf(0)
    var captchaInput by mutableStateOf("")
    var captchaVerified by mutableStateOf(false)
    var captchaError by mutableStateOf(false)
    var captchaQuestion by mutableStateOf("")

    // Redeem
    var redeemUtr by mutableStateOf("")
    var redeemMsg by mutableStateOf("")
    var redeemCode by mutableStateOf("")
    var redeemError by mutableStateOf(false)
    var redeemSuccess by mutableStateOf(false)
    var usedUtrs by mutableStateOf(listOf<String>())

    // Refer
    var myReferCode by mutableStateOf("")
    var referInput by mutableStateOf("")
    var referMsg by mutableStateOf("")
    var referStats by mutableStateOf(listOf<ReferEntry>())

    // Top-Up
    var topUpUtr by mutableStateOf("")
    var topUpMsg by mutableStateOf("")
    var topUpError by mutableStateOf(false)
    var topUpSuccess by mutableStateOf(false)

    // Code indices
    var codeIdx1000 by mutableStateOf(0)
    var codeIdx1650 by mutableStateOf(0)
    var codeIdx2000 by mutableStateOf(0)
    var deviceOffset by mutableStateOf(-1)

    // ── Load ───────────────────────────────────────────────────────────────────
    fun load(context: Context) {
        viewModelScope.launch {
            coins = AppDataStore.getCoins(context).first()
            bonusClaimed = AppDataStore.getBonusClaimed(context).first()
            myReferCode = AppDataStore.getMyReferCode(context).first()
            codeIdx1000 = AppDataStore.getCodeIdx(context, 1000).first()
            codeIdx1650 = AppDataStore.getCodeIdx(context, 1650).first()
            codeIdx2000 = AppDataStore.getCodeIdx(context, 2000).first()
            deviceOffset = AppDataStore.getDeviceOffset(context).first()

            val statsJson = AppDataStore.getReferStats(context).first()
            referStats = parseReferStats(statsJson)

            val utrsJson = AppDataStore.getUsedUtrs(context).first()
            usedUtrs = parseStringList(utrsJson)

            if (myReferCode.isEmpty()) {
                myReferCode = generateReferCode()
                AppDataStore.setMyReferCode(context, myReferCode)
            }
            if (deviceOffset == -1) {
                deviceOffset = Random.nextInt(CODES_1000.size)
                AppDataStore.setDeviceOffset(context, deviceOffset)
            }

            generateCaptcha()
            isLoaded = true
        }
    }

    // ── Coins ──────────────────────────────────────────────────────────────────
    fun addCoins(context: Context, amount: Double) {
        viewModelScope.launch {
            coins += amount
            AppDataStore.setCoins(context, coins)
        }
    }

    fun claimBonus(context: Context) {
        if (!bonusClaimed) {
            viewModelScope.launch {
                bonusClaimed = true
                AppDataStore.setBonusClaimed(context, true)
                addCoins(context, 50.0)
            }
        }
    }

    // ── Scratch ────────────────────────────────────────────────────────────────
    fun prepareScratch() {
        scratchRevealed = false
        scratchPrize = pickScratchPrize()
        scratchProgress = 0f
    }

    fun updateScratchProgress(progress: Float) {
        scratchProgress = progress
    }

    fun revealScratch(context: Context) {
        if (!scratchRevealed) {
            scratchRevealed = true
            val prize = scratchPrize ?: return
            if (prize.coins > 0) addCoins(context, prize.coins)
        }
    }

    // ── Quiz ───────────────────────────────────────────────────────────────────
    fun prepareQuiz() {
        quizQuestion = QUIZ_QUESTIONS.random()
        quizAnswered = false
        quizSelectedOption = -1
        quizResult = ""
    }

    fun answerQuiz(context: Context, optionIdx: Int) {
        val q = quizQuestion ?: return
        quizSelectedOption = optionIdx
        quizAnswered = true
        if (optionIdx == q.answer) {
            quizResult = "correct"
            addCoins(context, 10.0)
        } else {
            quizResult = "wrong"
        }
    }

    // ── Captcha ────────────────────────────────────────────────────────────────
    fun generateCaptcha() {
        val a = Random.nextInt(10, 50)
        val b = Random.nextInt(1, 20)
        captchaAnswer = a + b
        captchaQuestion = "$a + $b = ?"
        captchaInput = ""
        captchaVerified = false
        captchaError = false
    }

    fun verifyCaptcha(context: Context): Boolean {
        val input = captchaInput.trim().toIntOrNull()
        return if (input == captchaAnswer) {
            captchaVerified = true
            captchaError = false
            addCoins(context, 5.0)
            true
        } else {
            captchaError = true
            false
        }
    }

    // ── Redeem ─────────────────────────────────────────────────────────────────
    fun submitRedeem(context: Context, tierCoins: Int) {
        val utr = redeemUtr.trim()
        redeemMsg = ""
        redeemCode = ""
        redeemError = false
        redeemSuccess = false

        if (utr.length != 12 || !utr.all { it.isDigit() }) {
            redeemMsg = "❌ Invalid UTR! Must be 12 digits."
            redeemError = true
            return
        }
        if (usedUtrs.contains(utr)) {
            redeemMsg = "❌ This UTR has already been used."
            redeemError = true
            return
        }
        if (coins < tierCoins) {
            redeemMsg = "❌ Insufficient coins."
            redeemError = true
            return
        }

        viewModelScope.launch {
            val newUsed = usedUtrs + utr
            usedUtrs = newUsed
            AppDataStore.setUsedUtrs(context, serializeStringList(newUsed))

            val code = getNextCode(context, tierCoins)
            redeemCode = code
            redeemSuccess = true
            redeemMsg = "✅ Code: $code"

            coins -= tierCoins
            AppDataStore.setCoins(context, coins)
        }
    }

    private suspend fun getNextCode(context: Context, tier: Int): String {
        return when (tier) {
            1650 -> {
                val idx = codeIdx1650 % CODES_1650.size
                val adjustedIdx = (idx + deviceOffset) % CODES_1650.size
                val code = CODES_1650[adjustedIdx]
                codeIdx1650++
                AppDataStore.setCodeIdx(context, 1650, codeIdx1650)
                code
            }
            2000 -> {
                val idx = codeIdx2000 % CODES_2000.size
                val adjustedIdx = (idx + deviceOffset) % CODES_2000.size
                val code = CODES_2000[adjustedIdx]
                codeIdx2000++
                AppDataStore.setCodeIdx(context, 2000, codeIdx2000)
                code
            }
            else -> {
                val idx = codeIdx1000 % CODES_1000.size
                val adjustedIdx = (idx + deviceOffset) % CODES_1000.size
                val code = CODES_1000[adjustedIdx]
                codeIdx1000++
                AppDataStore.setCodeIdx(context, 1000, codeIdx1000)
                code
            }
        }
    }

    // ── Refer ──────────────────────────────────────────────────────────────────
    fun applyReferCode(context: Context) {
        val code = referInput.trim().uppercase()
        referMsg = ""
        if (code.isEmpty()) { referMsg = "❌ Enter a referral code."; return }
        if (code == myReferCode) { referMsg = "❌ Cannot use your own code."; return }
        if (referStats.any { it.code == code }) { referMsg = "❌ Already used."; return }

        viewModelScope.launch {
            val entry = ReferEntry(code, 20.0)
            val newStats = referStats + entry
            referStats = newStats
            AppDataStore.setReferStats(context, serializeReferStats(newStats))
            addCoins(context, 20.0)
            referMsg = "✅ +20 Coins! Referral applied."
            referInput = ""
        }
    }

    // ── Top-Up ─────────────────────────────────────────────────────────────────
    fun submitTopUp(context: Context) {
        val utr = topUpUtr.trim()
        topUpMsg = ""
        topUpError = false
        topUpSuccess = false

        if (utr.length != 12 || !utr.all { it.isDigit() }) {
            topUpMsg = "❌ Invalid UTR! Must be 12 digits."
            topUpError = true
            return
        }

        val amount = (utr.toLong() % 900 + 100).toDouble()
        viewModelScope.launch {
            addCoins(context, amount)
            topUpSuccess = true
            topUpMsg = "✅ +${amount.toInt()} coins added!"
            topUpUtr = ""
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────────
    private fun generateReferCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return "RC-" + (1..6).map { chars.random() }.joinToString("")
    }

    private fun parseReferStats(json: String): List<ReferEntry> {
        if (json.isBlank() || json == "[]") return emptyList()
        return try {
            json.removeSurrounding("[", "]").split("},{").map { part ->
                val clean = part.replace("{", "").replace("}", "")
                val map = clean.split(",").associate {
                    val (k, v) = it.split(":")
                    k.trim().removeSurrounding("\"") to v.trim().removeSurrounding("\"")
                }
                ReferEntry(map["code"] ?: "", map["coins"]?.toDoubleOrNull() ?: 0.0)
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun serializeReferStats(list: List<ReferEntry>): String =
        "[" + list.joinToString(",") { """{"code":"${it.code}","coins":${it.coins}}""" } + "]"

    private fun parseStringList(json: String): List<String> {
        if (json.isBlank() || json == "[]") return emptyList()
        return try {
            json.removeSurrounding("[", "]").split(",").map { it.trim().removeSurrounding("\"") }
        } catch (e: Exception) { emptyList() }
    }

    private fun serializeStringList(list: List<String>): String =
        "[" + list.joinToString(",") { "\"$it\"" } + "]"
}
