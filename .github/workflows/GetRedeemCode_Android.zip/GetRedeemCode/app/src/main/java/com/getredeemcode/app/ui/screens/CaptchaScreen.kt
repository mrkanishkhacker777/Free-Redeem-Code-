package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel

@Composable
fun CaptchaScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            TopBar(title = "🔢 Captcha Verify", onBack = onBack, coins = vm.coins)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                // Info card
                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Solve the math captcha", color = TextGray, fontSize = 13.sp)
                            Text("+5 Coins!", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        }
                        Text("🔢", fontSize = 48.sp)
                    }
                }

                // Captcha display
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.linearGradient(listOf(Color(0xFF1E1B4B), Color(0xFF312E81)))
                        )
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "Solve this:",
                            color = TextGray,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            vm.captchaQuestion,
                            color = TextWhite,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 36.sp,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Human verification",
                            color = PurpleLight,
                            fontSize = 12.sp
                        )
                    }
                }

                // Input
                OutlinedTextField(
                    value = vm.captchaInput,
                    onValueChange = {
                        vm.captchaInput = it
                        vm.captchaError = false
                    },
                    placeholder = { Text("Enter your answer", color = TextMuted) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedBorderColor = if (vm.captchaError) Red else Purple,
                        unfocusedBorderColor = if (vm.captchaError) Red.copy(0.5f) else Purple.copy(0.3f),
                        cursorColor = Purple,
                        focusedContainerColor = CardBg2.copy(alpha = 0.3f),
                        unfocusedContainerColor = CardBg2.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    isError = vm.captchaError
                )

                if (vm.captchaError) {
                    Text("❌ Wrong answer! Try again.", color = Red, fontSize = 14.sp)
                }

                if (vm.captchaVerified) {
                    GradientCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = listOf(Color(0xFF065F46), Color(0xFF047857)),
                        borderColor = Green.copy(0.4f)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("✅ Verified!", color = GreenLight, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text("+5 Coins added!", color = GreenLight, fontSize = 14.sp)
                        }
                    }

                    GradientButton(
                        text = "New Captcha",
                        emoji = "🔄",
                        onClick = { vm.generateCaptcha() },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    GradientButton(
                        text = "Verify",
                        emoji = "✔️",
                        onClick = { vm.verifyCaptcha(context) },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = vm.captchaInput.isNotBlank()
                    )
                }

                // Info
                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Text("ℹ️ How it works", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Solve the math problem to prove you're human and earn 5 coins. " +
                        "Each verification gives you a new problem. Complete multiple times to earn more!",
                        color = TextGray,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
