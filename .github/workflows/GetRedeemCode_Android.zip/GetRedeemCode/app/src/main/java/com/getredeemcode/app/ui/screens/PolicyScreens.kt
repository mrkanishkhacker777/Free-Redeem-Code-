package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.getredeemcode.app.ui.theme.*

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            TopBar(title = "🔒 Privacy Policy", onBack = onBack)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Privacy Policy", color = TextWhite, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Last updated: January 2025", color = TextMuted, fontSize = 13.sp)
                }

                listOf(
                    "1. Information We Collect" to
                        "We collect minimal data necessary to provide our services. This includes app usage statistics and coin balance which are stored locally on your device. We do not collect personal identification information.",

                    "2. How We Use Information" to
                        "Your coin balance and preferences are stored locally on your device using Android DataStore. We do not transmit personal data to external servers.",

                    "3. Data Storage" to
                        "All app data (coins, referral codes, preferences) is stored locally on your device. Uninstalling the app will delete all stored data.",

                    "4. Third-Party Services" to
                        "This app does not integrate with third-party analytics or advertising platforms. No personal data is shared with third parties.",

                    "5. Children's Privacy" to
                        "This app is not directed at children under 13. We do not knowingly collect data from children.",

                    "6. Changes to Policy" to
                        "We may update this policy periodically. Continued use of the app after changes constitutes acceptance of the new policy.",

                    "7. Contact" to
                        "For privacy concerns, please contact us through the app store listing."
                ).forEach { (title, content) ->
                    GradientCard(modifier = Modifier.fillMaxWidth()) {
                        Text(title, color = PurpleLight, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(content, color = TextGray, fontSize = 13.sp, lineHeight = 20.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun TermsScreen(onBack: () -> Unit) {
    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            TopBar(title = "📜 Terms of Service", onBack = onBack)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Terms of Service", color = TextWhite, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Last updated: January 2025", color = TextMuted, fontSize = 13.sp)
                }

                listOf(
                    "1. Acceptance" to
                        "By using Get Redeem Code, you agree to these terms. If you do not agree, please do not use the app.",

                    "2. App Purpose" to
                        "This app is for educational and entertainment purposes only. Coins earned within the app have no real monetary value and cannot be exchanged for real money.",

                    "3. Redeem Codes" to
                        "Redeem codes are provided for entertainment purposes. We make no guarantees about their validity or usability on any third-party platform. Each UTR can only be used once.",

                    "4. Top-Up Payments" to
                        "Any payments made through the Top-Up feature are non-refundable. These payments are for entertainment services only. By making a payment, you acknowledge that coins have no real monetary value.",

                    "5. Prohibited Activities" to
                        "Users must not attempt to manipulate the coin system, share false referral codes, or use the app for any fraudulent activity. Violations may result in account suspension.",

                    "6. Disclaimer" to
                        "This app is not affiliated with, endorsed by, or connected to Google, Amazon, Flipkart, or any other brand. All brand names mentioned are trademarks of their respective owners.",

                    "7. Limitation of Liability" to
                        "We are not liable for any direct or indirect damages arising from your use of the app. The app is provided 'as is' without warranties of any kind.",

                    "8. Changes" to
                        "We reserve the right to modify these terms at any time. Continued use of the app constitutes acceptance of modified terms.",

                    "9. Governing Law" to
                        "These terms are governed by applicable laws. Any disputes shall be resolved through binding arbitration."
                ).forEach { (title, content) ->
                    GradientCard(modifier = Modifier.fillMaxWidth()) {
                        Text(title, color = PurpleLight, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(content, color = TextGray, fontSize = 13.sp, lineHeight = 20.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
