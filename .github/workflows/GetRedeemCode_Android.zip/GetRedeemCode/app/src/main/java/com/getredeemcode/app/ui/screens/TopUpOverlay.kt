package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel

@Composable
fun TopUpOverlay(vm: AppViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.verticalGradient(listOf(CardBg, CardBg2)))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("⚡ Top-Up Coins", color = TextWhite, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Send money via UPI and enter UTR to add coins automatically.",
                color = TextGray,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // UPI box
            GradientCard(
                modifier = Modifier.fillMaxWidth(),
                colors = listOf(Color(0xFF065F46), Color(0xFF064E3B)),
                borderColor = Green.copy(alpha = 0.4f)
            ) {
                Text("UPI ID", color = TextMuted, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("payment@upi", color = GreenLight, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Min ₹1 • Coins added automatically", color = TextGray, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            StyledTextField(
                value = vm.topUpUtr,
                onValueChange = {
                    vm.topUpUtr = it
                    vm.topUpMsg = ""
                    vm.topUpError = false
                    vm.topUpSuccess = false
                },
                placeholder = "Enter 12-digit UTR number"
            )

            if (vm.topUpMsg.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    vm.topUpMsg,
                    color = if (vm.topUpSuccess) GreenLight else RedLight,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextGray),
                    border = ButtonDefaults.outlinedButtonBorder.copy()
                ) {
                    Text("Cancel")
                }
                GradientButton(
                    text = "Submit",
                    emoji = "✅",
                    onClick = {
                        vm.submitTopUp(context)
                    },
                    modifier = Modifier.weight(1f),
                    colors = listOf(Green, Cyan)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                "⚠️ Payments are non-refundable. Coins have no real monetary value.",
                color = TextMuted,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
