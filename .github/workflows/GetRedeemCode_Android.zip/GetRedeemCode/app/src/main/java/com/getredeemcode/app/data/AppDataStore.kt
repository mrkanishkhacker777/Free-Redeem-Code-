package com.getredeemcode.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "rc_prefs")

object AppDataStore {
    private val COINS_KEY = doublePreferencesKey("rc_coins")
    private val BONUS_CLAIMED_KEY = booleanPreferencesKey("rc_bonusClaimed")
    private val VISITED_KEY = booleanPreferencesKey("rc_visited")
    private val MY_REFER_CODE_KEY = stringPreferencesKey("rc_my_refer_code")
    private val REFER_STATS_KEY = stringPreferencesKey("rc_refer_stats")
    private val CAPTCHA_DATA_KEY = stringPreferencesKey("captcha_data")
    private val USED_UTRS_KEY = stringPreferencesKey("rc_used_utrs")
    private val CODE_IDX_1000_KEY = intPreferencesKey("rc_codeIdx_1000")
    private val CODE_IDX_1650_KEY = intPreferencesKey("rc_codeIdx_1650")
    private val CODE_IDX_2000_KEY = intPreferencesKey("rc_codeIdx_2000")
    private val DEVICE_OFFSET_KEY = intPreferencesKey("rc_device_offset")

    fun getCoins(context: Context): Flow<Double> =
        context.dataStore.data.map { it[COINS_KEY] ?: 0.0 }

    suspend fun setCoins(context: Context, value: Double) {
        context.dataStore.edit { it[COINS_KEY] = value }
    }

    fun getBonusClaimed(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[BONUS_CLAIMED_KEY] ?: false }

    suspend fun setBonusClaimed(context: Context, value: Boolean) {
        context.dataStore.edit { it[BONUS_CLAIMED_KEY] = value }
    }

    fun getVisited(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[VISITED_KEY] ?: false }

    suspend fun setVisited(context: Context, value: Boolean) {
        context.dataStore.edit { it[VISITED_KEY] = value }
    }

    fun getMyReferCode(context: Context): Flow<String> =
        context.dataStore.data.map { it[MY_REFER_CODE_KEY] ?: "" }

    suspend fun setMyReferCode(context: Context, value: String) {
        context.dataStore.edit { it[MY_REFER_CODE_KEY] = value }
    }

    fun getReferStats(context: Context): Flow<String> =
        context.dataStore.data.map { it[REFER_STATS_KEY] ?: "" }

    suspend fun setReferStats(context: Context, value: String) {
        context.dataStore.edit { it[REFER_STATS_KEY] = value }
    }

    fun getCaptchaData(context: Context): Flow<String> =
        context.dataStore.data.map { it[CAPTCHA_DATA_KEY] ?: "" }

    suspend fun setCaptchaData(context: Context, value: String) {
        context.dataStore.edit { it[CAPTCHA_DATA_KEY] = value }
    }

    fun getUsedUtrs(context: Context): Flow<String> =
        context.dataStore.data.map { it[USED_UTRS_KEY] ?: "[]" }

    suspend fun setUsedUtrs(context: Context, value: String) {
        context.dataStore.edit { it[USED_UTRS_KEY] = value }
    }

    fun getCodeIdx(context: Context, tier: Int): Flow<Int> {
        val key = when (tier) {
            1650 -> CODE_IDX_1650_KEY
            2000 -> CODE_IDX_2000_KEY
            else -> CODE_IDX_1000_KEY
        }
        return context.dataStore.data.map { it[key] ?: 0 }
    }

    suspend fun setCodeIdx(context: Context, tier: Int, value: Int) {
        val key = when (tier) {
            1650 -> CODE_IDX_1650_KEY
            2000 -> CODE_IDX_2000_KEY
            else -> CODE_IDX_1000_KEY
        }
        context.dataStore.edit { it[key] = value }
    }

    fun getDeviceOffset(context: Context): Flow<Int> =
        context.dataStore.data.map { it[DEVICE_OFFSET_KEY] ?: -1 }

    suspend fun setDeviceOffset(context: Context, value: Int) {
        context.dataStore.edit { it[DEVICE_OFFSET_KEY] = value }
    }
}
