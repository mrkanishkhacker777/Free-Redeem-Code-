package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel

@Composable
fun ReferScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            TopBar(title = "👥 Refer & Earn", onBack = onBack, coins = vm.coins)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                // Stats
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(modifier = Modifier.weight(1f), emoji = "👥", value = "${vm.referStats.size}", label = "Referrals")
                    StatCard(modifier = Modifier.weight(1f), emoji = "🪙", value = "${vm.referStats.size * 20}", label = "Earned")
                }

                // My code
                GradientCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = listOf(Color(0xFF4C1D95), Color(0xFF6D28D9))
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Your Referral Code", color = PurpleLight, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black.copy(0.3f))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                vm.myReferCode,
                                color = TextWhite,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 26.sp,
                                letterSpacing = 3.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        GradientButton(
                            text = if (copied) "Copied!" else "Copy Code",
                            emoji = if (copied) "✅" else "📋",
                            onClick = {
                                clipboard.setText(AnnotatedString(vm.myReferCode))
                                copied = true
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = if (copied) listOf(Green, GreenLight) else listOf(Purple, Pink)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Share this code and earn +20 coins per referral!", color = PurpleLight, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }
                }

                // Enter referral
                Text("Enter Friend's Code", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)

                StyledTextField(
                    value = vm.referInput,
                    onValueChange = {
                        vm.referInput = it.uppercase()
                        vm.referMsg = ""
                    },
                    placeholder = "Enter referral code (e.g. RC-ABCD12)"
                )

                if (vm.referMsg.isNotEmpty()) {
                    Text(
                        vm.referMsg,
                        color = if (vm.referMsg.startsWith("✅")) GreenLight else RedLight,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                GradientButton(
                    text = "Apply Code",
                    emoji = "🎯",
                    onClick = { vm.applyReferCode(context) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = vm.referInput.isNotBlank()
                )

                // History
                if (vm.referStats.isNotEmpty()) {
                    Text("Referral History", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)

                    GradientCard(modifier = Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            vm.referStats.forEachIndexed { idx, entry ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("🤝", fontSize = 20.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(entry.code, color = TextWhite, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                            Text("Referral #${idx + 1}", color = TextMuted, fontSize = 12.sp)
                                        }
                                    }
                                    InfoBadge("+${entry.coins.toInt()} 🪙", color = Green)
                                }
                                if (idx < vm.referStats.size - 1) {
                                    Divider(color = Purple.copy(0.2f))
                                }
                            }
                        }
                    }
                }

                // How it works
                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Text("How Referral Works", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    listOf(
                        "1️⃣" to "Copy your unique referral code above",
                        "2️⃣" to "Share it with friends",
                        "3️⃣" to "They enter your code in the app",
                        "4️⃣" to "You earn +20 coins per referral!"
                    ).forEach { (step, desc) ->
                        Row(
                            modifier = Modifier.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(step, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(desc, color = TextGray, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
