package com.getredeemcode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.getredeemcode.app.ui.theme.*
import com.getredeemcode.app.viewmodel.AppViewModel

@Composable
fun QuizScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val q = vm.quizQuestion

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            TopBar(title = "🧠 Quiz Time", onBack = onBack, coins = vm.coins)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                // Info
                GradientCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Answer correctly to earn", color = TextGray, fontSize = 13.sp)
                            Text("+10 Coins!", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        }
                        Text("🧠", fontSize = 48.sp)
                    }
                }

                if (q != null) {
                    // Question
                    GradientCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = listOf(Color(0xFF1E1B4B), Color(0xFF312E81))
                    ) {
                        Text(
                            q.question,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Options
                    q.options.forEachIndexed { idx, option ->
                        val isSelected = vm.quizSelectedOption == idx
                        val isCorrect = idx == q.answer
                        val bgColor = when {
                            !vm.quizAnswered -> if (isSelected) Purple.copy(0.3f) else Color.Transparent
                            isCorrect -> Green.copy(0.3f)
                            isSelected && !isCorrect -> Red.copy(0.3f)
                            else -> Color.Transparent
                        }
                        val borderColor = when {
                            !vm.quizAnswered -> Purple.copy(0.4f)
                            isCorrect -> Green
                            isSelected && !isCorrect -> Red
                            else -> Purple.copy(0.2f)
                        }
                        val emoji = when {
                            !vm.quizAnswered -> "⬜"
                            isCorrect -> "✅"
                            isSelected && !isCorrect -> "❌"
                            else -> "⬜"
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(bgColor)
                                .border(1.5.dp, borderColor, RoundedCornerShape(14.dp))
                                .clickable(enabled = !vm.quizAnswered) { vm.answerQuiz(context, idx) }
                                .padding(16.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(emoji, fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(option, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    // Result
                    if (vm.quizAnswered) {
                        GradientCard(
                            modifier = Modifier.fillMaxWidth(),
                            colors = if (vm.quizResult == "correct")
                                listOf(Color(0xFF065F46), Color(0xFF047857))
                            else
                                listOf(Color(0xFF1F0A0A), Color(0xFF2D1010)),
                            borderColor = if (vm.quizResult == "correct") Green.copy(0.4f) else Red.copy(0.3f)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    if (vm.quizResult == "correct") "🎉 Correct! +10 Coins!" else "❌ Wrong Answer!",
                                    color = if (vm.quizResult == "correct") GreenLight else RedLight,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                if (vm.quizResult == "wrong") {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Correct: ${q.options[q.answer]}",
                                        color = GreenLight,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }

                        GradientButton(
                            text = "Next Question",
                            emoji = "➡️",
                            onClick = { vm.prepareQuiz() },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
