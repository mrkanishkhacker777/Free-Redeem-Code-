package com.getredeemcode.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.getredeemcode.app.ui.theme.*

@Composable
fun LoginScreen(onEnter: () -> Unit) {
    var agreed by remember { mutableStateOf(false) }

    GradientBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            // Hero emoji
            Text("🎁", fontSize = 72.sp)
            Spacer(modifier = Modifier.height(16.dp))

            Text(
                "Get Redeem Code",
                color = TextWhite,
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Complete tasks, earn coins,\nredeem real rewards!",
                color = TextGray,
                fontSize = 16.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(36.dp))

            // Features
            GradientCard(modifier = Modifier.fillMaxWidth()) {
                listOf(
                    "🎰" to "Scratch & Win up to 100 coins",
                    "🧠" to "Quiz: Answer & earn 10 coins",
                    "🔢" to "Captcha verify: +5 coins",
                    "👥" to "Refer friends: +20 coins each",
                    "💰" to "Redeem codes with 1000+ coins"
                ).forEach { (emoji, text) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(emoji, fontSize = 22.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text, color = TextGray, fontSize = 14.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Disclaimer card
            GradientCard(
                modifier = Modifier.fillMaxWidth(),
                colors = listOf(Color(0xFF1F0A0A), Color(0xFF2D0F0F)),
                borderColor = Red.copy(alpha = 0.4f)
            ) {
                Text(
                    "⚠️ Disclaimer",
                    color = Red,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "This app is for educational & entertainment purposes only. " +
                    "Coins and codes have no real monetary value. " +
                    "Top-up payments are non-refundable. " +
                    "We are not affiliated with Google, Amazon, or any other brand.",
                    color = TextGray,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Agree checkbox
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(
                    checked = agreed,
                    onCheckedChange = { agreed = it },
                    colors = CheckboxDefaults.colors(
                        checkedColor = Purple,
                        uncheckedColor = TextMuted,
                        checkmarkColor = TextWhite
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "I agree to the Terms & Conditions and Privacy Policy",
                    color = TextGray,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            GradientButton(
                text = "Enter App",
                emoji = "🚀",
                onClick = onEnter,
                enabled = agreed,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 18
            )

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                "v1.0 • Get Redeem Code",
                color = TextMuted,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
